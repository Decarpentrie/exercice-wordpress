<div class="caldera-config-group">
	<label for="{{_id}}editor">
        <?php esc_html_e('Content', 'caldera-forms'); ?>
    </label>
</div>
<div style="clear:both;"></div>
<div style="position:relative;">
	<textarea class="block-input field-config magic-tag-enabled" name="{{_name}}[default]" id="{{_id}}editor" style="resize:vertical; height:200px;">{{default}}</textarea>
</div>